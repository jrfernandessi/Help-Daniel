
public class FormaGeometrica {
	private double lado1;
	
	public double calcArea() {
		return 0;
	}
	
	public double calcPerimetro() {
		return 0;
	}
	
	public void exibirDados() {
		System.out.println(this.calcArea());
		System.out.println(this.calcPerimetro());
	}

	public double getLado1() {
		return lado1;
	}

	public void setLado1(double lado1) {
		this.lado1 = lado1;
	}
	
	
}
