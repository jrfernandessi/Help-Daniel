
public class UsaFormaGeometrica {
	public static void main(String[] args) {
		FormaGeometrica quadrado = new Quadrado();
		quadrado.setLado1(3);
		quadrado.exibirDados();
		
	}
}
